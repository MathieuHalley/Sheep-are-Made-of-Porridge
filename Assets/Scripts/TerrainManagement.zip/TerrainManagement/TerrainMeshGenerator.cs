﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

public interface ITerrainMeshGenerator
{
	Mesh             Mesh      { get; }
	List<Collider2D> Colliders { get; }
	ITerrainNode[]   Nodes     { get; }
	void GenerateMesh();
	void GenerateColliders();
	ITerrainNode GetNode(int index);
	ITerrainNode GetNode(int x, int y);
	int GetNodeIndex(ITerrainNode node);
	// bool SetNode(int index, ITerrainNode value);
	// bool SetNode(int x, int y, ITerrainNode value);
}

public interface ITerrainNode
{
	IStatus            Status                { get; }
	Vector3            Position              { get; }
	ITerrainNode[]     Neighbours            { get; }
	List<ITerrainNode> NullCheckedNeighbours { get; }
	void SetNeighbours(ITerrainNode[] neighbours);
}

public interface IStatus { }

public class TerrainMeshGenerator : ITerrainMeshGenerator
{
	private readonly int   gridHeight;
	private readonly int   gridWidth;
	private readonly float nodeHeight;
	private readonly float nodeWidth;
	private Mesh             mesh;
	private List<Collider2D> colliders;
	private ITerrainNode[]   nodes;
	private List<Vector3>    vertices;
	private List<int>        triangles;

	public Mesh Mesh { get { return mesh; } }
	public List<Collider2D> Colliders { get { return colliders; } }
	public ITerrainNode[]   Nodes     { get { return nodes; } }

	private TerrainMeshGenerator()
	{
		mesh      = new Mesh();
		vertices  = new List<Vector3>();
		triangles = new List<int>();
		colliders = new List<Collider2D>();
	}

	public TerrainMeshGenerator(Vector3 origin, Vector2 gridSize, Vector2 nodeSize)
		: this()
	{
		gridHeight = (int)gridSize.y;
		gridWidth  = (int)gridSize.x;
		nodeHeight     = nodeSize.x;
		nodeWidth      = nodeSize.y;
		nodes = new ITerrainNode[gridHeight * gridWidth];

	}

	public void GenerateMesh()
	{
		throw new NotImplementedException();
	}

	public void GenerateColliders()
	{
		throw new NotImplementedException();
	}

	public ITerrainNode GetNode(int index)
	{
		return nodes[index];
	}
	public ITerrainNode GetNode(int x, int y)
	{
		return nodes[x + y * gridWidth];
	}

	public int GetNodeIndex(ITerrainNode node)
	{
		return nodes.ToList().IndexOf(node);
	}

	private void SetNode(int index, ITerrainNode value)
	{
		nodes[index] = value;
	}

	private void SetNode(int x, int y, ITerrainNode value)
	{
		nodes[x + y * gridWidth] = value;
	}

	private void IdentifyNodeNeighbours()
	{
		ITerrainNode[] neighbours = new ITerrainNode[8];
		int above, below, left, right;

		int x, y, l, r, u, d;
		for (x = 0; x < gridWidth; ++x)
		{
			l = x - 1;
			r = x + 1;
			for (y = 0; y < gridHeight; ++y)
			{
				d = y - 1;
				u = y + 1;
				/*
				neighbours = new ITerrainNode[8] {
					(l >= 0 && d >= 0)                ? GetNode(l, d) : null,
					(d >= 0)                          ? GetNode(x, d) : null,
					(r < gridWidth && d >= 0)         ? GetNode(r, d) : null,
					(l >= 0)                          ? GetNode(l, y) : null,
					(r < gridWidth)                   ? GetNode(r, y) : null,
					(l >= 0 && u < gridHeight)        ? GetNode(l, u) : null,
					(u < gridHeight)                  ? GetNode(x, u) : null,
					(r < gridWidth && u < gridHeight) ? GetNode(r, u) : null
				};
				x + y * gridWidth
				*/
				GetNode(x, y).SetNeighbours(neighbours);
			}
		}

		for (int i = 0; i < nodes.Length; ++i)
		{
			x = i % gridWidth;
			y = i / gridWidth;
			above = y + 1;
			below = y - 1;
			left  = x - 1;
			right = x + 1;
			nodes[i].SetNeighbours(
				new ITerrainNode[8] {
					(left >= 0 && below >= 0)                 ? nodes[left  + below] : null,
					(below >= 0)                              ? nodes[x     + below] : null,
					(right < gridWidth && below >= 0)         ? nodes[right + below] : null,
					(left  >= 0)                              ? nodes[left  + y]     : null,
					(right < gridWidth)                       ? nodes[right + y]     : null,
					(left >= 0 && above < gridHeight)         ? nodes[left  + above] : null,
					(above < gridHeight)                      ? nodes[x     + above] : null,
					(right < gridWidth && above < gridHeight) ? nodes[right + above] : null});
		}
	}
}

public class TerrainNode : ITerrainNode
{
	private ITerrainNode[] neighbours;
	private Vector3        position;
	private IStatus        status;
	public  ITerrainNode[]     Neighbours { get { return neighbours; } }
	public  Vector3            Position   { get { return position; } }
	public  IStatus            Status     { get { return status; } }
	public  List<ITerrainNode> NullCheckedNeighbours
	{
		get
		{
			return neighbours
				.AsEnumerable()
				.Where(node => node != null)
				.ToList();
		}
	}

	private TerrainNode()
	{
		neighbours = new ITerrainNode[8];
		position   = Vector3.zero;
		status     = default(IStatus);
	}

	public TerrainNode(Vector3 position, IStatus status) : this()
	{
		this.position = position;
		this.status   = status;
	}

	public void SetNeighbours(ITerrainNode[] neighbours)
	{
		this.neighbours = neighbours;
	} 
}

/*
public class TerrainMeshGenerator : MonoBehaviour
{
	public List<Vector3>        vertices;
	public List<int>            triangles;
	public List<Vector3>        edgeVertices;
	public List<int>            edgeTriangles;
	private SquareGrid          squareGrid;
	public List<List<Vector3>> edgeSegments;

	public void Initialize(TerrainVoxelMap map, float nodeSize)
	{
		squareGrid = new SquareGrid(map, nodeSize);
		edgeSegments = new List<List<Vector3>>();
	}

	public void GenerateMesh()
	{
		vertices   = new List<Vector3>();
		triangles  = new List<int>();
		Mesh mesh  = new Mesh();
		edgeVertices  = new List<Vector3>();
		edgeTriangles = new List<int>();
		edgeSegments  = new List<List<Vector3>>();

		for (int y = 0; y < squareGrid.squares.GetLength(1); ++y)
		{
			for (int x = 0; x < squareGrid.squares.GetLength(0); ++x)
			{
				TriangulateSquare(squareGrid.squares[x, y]);
			}
		}
		GenerateColliders();
		MeshFilter meshFilter = GetComponent<MeshFilter>();
		meshFilter.mesh.Clear();
		meshFilter.mesh = mesh;
		
		mesh.vertices   = vertices.ToArray();
		mesh.triangles  = triangles.ToArray();
		mesh.Optimize();
		mesh.RecalculateNormals();
	}

	private void GenerateColliders()
	{
		EdgeCollider2D[] currentColliders
			= gameObject.GetComponents<EdgeCollider2D>();
		for (int i = 0; i < currentColliders.Length; ++i)
		{
			Destroy(currentColliders[i]);
		}
		MergeEdgeSegments();

		foreach (List<Vector3> edges in edgeSegments)
		{
			EdgeCollider2D edgeCollider
				= gameObject.AddComponent<EdgeCollider2D>();
			Vector2[] edgepoints = new Vector2[edges.Count];
			for (int i = 0; i < edges.Count; ++i)
			{
				edgepoints[i] = edges[i];
			}
			edgeCollider.points = edgepoints;
		}
	}

	public void SetControlNodeState(int x, int y, bool newState)
	{
		if (x >= squareGrid.controlNodes.GetLength(0) || 
			y >= squareGrid.controlNodes.GetLength(1) || 
			x < 0 || 
			y < 0)
		{
			return;
		}
		squareGrid.controlNodes[x, y].active = newState;
		foreach (Square square in squareGrid.squares)
		{
			square.UpdateConfiguration();
		}
	}

	private void TriangulateSquare(Square square)
	{
		switch (square.configuration)
		{
			case 0:
				break;
			case 1:
				AddEdgeSegment(
					square.centerLeft.position,
					square.centerBottom.position);
				AddTriangle(
					square.centerBottom.position, 
					square.bottomLeft.position, 
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 2:
				AddEdgeSegment(
					square.centerBottom.position,
					square.centerRight.position);
				AddTriangle(
					square.centerRight.position, 
					square.bottomRight.position, 
					square.centerBottom.position,
					edgeVertices, edgeTriangles);
				break;
			case 4:
				AddEdgeSegment(
					square.centerRight.position,
					square.centerTop.position);
				AddTriangle(
					square.centerTop.position, 
					square.topRight.position, 
					square.centerRight.position,
					edgeVertices, edgeTriangles);
				break;
			case 8:
				AddEdgeSegment(
					square.centerTop.position,
					square.centerLeft.position);
				AddTriangle(
					square.topLeft.position, 
					square.centerTop.position, 
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 3:
				AddEdgeSegment(
					square.centerLeft.position,
					square.centerRight.position);
				AddQuad(
					square.centerRight.position,
					square.bottomRight.position,
					square.bottomLeft.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 6:
				AddEdgeSegment(
					square.centerBottom.position,
					square.centerTop.position);
				AddQuad(
					square.centerTop.position,
					square.topRight.position,
					square.bottomRight.position,
					square.centerBottom.position,
					edgeVertices, edgeTriangles);
				break;
			case 9:
				AddEdgeSegment(
					square.centerTop.position,
					square.centerBottom.position);
				AddQuad(
					square.topLeft.position,
					square.centerTop.position,
					square.centerBottom.position,
					square.bottomLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 12:
				AddEdgeSegment(
					square.centerRight.position,
					square.centerLeft.position);
				AddQuad(
					square.topLeft.position,
					square.topRight.position,
					square.centerRight.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 5:
				AddEdgeSegment(
					square.centerRight.position,
					square.centerBottom.position);
				AddEdgeSegment(
					square.centerLeft.position,
					square.centerTop.position);
				AddHexagon(
					square.centerTop.position,
					square.topRight.position,
					square.centerRight.position,
					square.centerBottom.position,
					square.bottomLeft.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 10:
				AddEdgeSegment(
					square.centerTop.position,
					square.centerRight.position);
				AddEdgeSegment(
					square.centerBottom.position,
					square.centerLeft.position);
				AddHexagon(
					square.topLeft.position,
					square.centerTop.position,
					square.centerRight.position,
					square.bottomRight.position,
					square.centerBottom.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 7:
				AddEdgeSegment(
					square.centerLeft.position,
					square.centerTop.position);
				AddPentagon(
					square.centerTop.position,
					square.topRight.position,
					square.bottomRight.position,
					square.bottomLeft.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 11:
				AddEdgeSegment(
					square.centerTop.position,
					square.centerRight.position);
				AddPentagon(
					square.topLeft.position,
					square.centerTop.position,
					square.centerRight.position,
					square.bottomRight.position,
					square.bottomLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 13:
				AddEdgeSegment(
					square.centerRight.position,
					square.centerBottom.position);
				AddPentagon(
					square.topLeft.position,
					square.topRight.position,
					square.centerRight.position,
					square.centerBottom.position,
					square.bottomLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 14:
				AddEdgeSegment(
					square.centerBottom.position,
					square.centerLeft.position);
				AddPentagon(
					square.topLeft.position,
					square.topRight.position,
					square.bottomRight.position,
					square.centerBottom.position,
					square.centerLeft.position,
					edgeVertices, edgeTriangles);
				break;
			case 15:
				AddQuad(
					square.topLeft.position,
					square.topRight.position,
					square.bottomRight.position,
					square.bottomLeft.position,
					vertices, triangles);
				break;
		}
	}

	private void AddEdgeSegment(Vector3 startPosition, Vector3 endPosition)
	{
		edgeSegments.Add(new List<Vector3> { startPosition, endPosition });
	}

	private void MergeEdgeSegments()
	{
		for (int i = edgeSegments.Count - 1; i >= 0; --i)
		{
			for (int j = edgeSegments.Count - 1; j >= 0; --j)
			{
				if (i == j) continue;
				if (edgeSegments[i].Last() == edgeSegments[j].First())
				{
					edgeSegments[j].RemoveAt(0);
					edgeSegments[i].AddRange(edgeSegments[j]);
					edgeSegments.Remove(edgeSegments[j]);
					i = Mathf.Min(i, edgeSegments.Count - 1);
					j = Mathf.Min(j, edgeSegments.Count - 1);
					continue;
				}
			}
		}
	}

	private void AddTriangle(
		Vector3 a, Vector3 b, Vector3 c, 
		List<Vector3> vertices, List<int> triangles)
	{
		vertices.AddRange(new List<Vector3> { a, b, c }.Except(vertices));
		int aIndex = vertices.IndexOf(a);
		int bIndex = vertices.IndexOf(b);
		int cIndex = vertices.IndexOf(c);
		triangles.AddRange(new int[] { aIndex, bIndex, cIndex });
	}

	private void AddQuad(
		Vector3 a, Vector3 b, Vector3 c, Vector3 d, 
		List<Vector3> vertices, List<int> triangles)
	{
		vertices.AddRange(new List<Vector3> { a, b, c, d }.Except(vertices));
		int aIndex = vertices.IndexOf(a);
		int bIndex = vertices.IndexOf(b);
		int cIndex = vertices.IndexOf(c);
		int dIndex = vertices.IndexOf(d);
		triangles.AddRange(new int[] { aIndex, bIndex, cIndex });
		triangles.AddRange(new int[] { aIndex, cIndex, dIndex });
	}

	private void AddPentagon(
		Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 e,
		List<Vector3> vertices, List<int> triangles)
	{
		vertices.AddRange(new List<Vector3> { a, b, c, d, e }.Except(vertices));
		int aIndex = vertices.IndexOf(a);
		int bIndex = vertices.IndexOf(b);
		int cIndex = vertices.IndexOf(c);
		int dIndex = vertices.IndexOf(d);
		int eIndex = vertices.IndexOf(e);
		triangles.AddRange(new int[] { aIndex, bIndex, cIndex });
		triangles.AddRange(new int[] { aIndex, cIndex, dIndex });
		triangles.AddRange(new int[] { aIndex, dIndex, eIndex });
	}

	private void AddHexagon(
		Vector3 a, Vector3 b, Vector3 c, Vector3 d, Vector3 e, Vector3 f, 
		List<Vector3> vertices, List<int> triangles)
	{
		vertices.AddRange(new List<Vector3>{ a, b, c, d, e, f }.Except(vertices));
		int aIndex = vertices.IndexOf(a);
		int bIndex = vertices.IndexOf(b);
		int cIndex = vertices.IndexOf(c);
		int dIndex = vertices.IndexOf(d);
		int eIndex = vertices.IndexOf(e);
		int fIndex = vertices.IndexOf(f);
		triangles.AddRange(new int[] { aIndex, bIndex, cIndex });
		triangles.AddRange(new int[] { aIndex, cIndex, dIndex });
		triangles.AddRange(new int[] { aIndex, dIndex, fIndex });
		triangles.AddRange(new int[] { dIndex, eIndex, fIndex });
	}

	private void OnDrawGizmos()
	{
		if (squareGrid != null)
		{
	//		DrawTriangleGizmo(vertices, triangles, Color.white);
			DrawTriangleGizmo(edgeVertices, edgeTriangles, Color.white);
			Gizmos.color = Color.red;
			for (int i = 0; i < edgeSegments.Count; ++i)
			{
				for (int j = 0; j < edgeSegments[i].Count - 1; ++j)
				{
					Gizmos.DrawLine(edgeSegments[i][j], edgeSegments[i][j + 1]);
				}
			}
		}
	}

	private void DrawTriangleGizmo(List<Vector3> vertices, List<int> triangles, Color color)
	{
		Gizmos.color = color;
		for (int i = 0; i < triangles.Count - 3; i += 3)
		{
			Gizmos.DrawLine(vertices[triangles[i]], vertices[triangles[i + 1]]);
			Gizmos.DrawLine(vertices[triangles[i + 1]], vertices[triangles[i + 2]]);
			Gizmos.DrawLine(vertices[triangles[i + 2]], vertices[triangles[i + 1]]);
		}
	}

	private class SquareGrid
	{
		public Square[,] squares;
		public ControlNode[,] controlNodes;

		public SquareGrid(TerrainVoxelMap map, float nodeSize)
		{
			int nodeCountXY     = map.chunkCountXY * map.voxelCountXY;
			float mapWidth      = nodeCountXY * nodeSize;
			float mapHeight     = nodeCountXY * nodeSize;
			float halfMapWidth  = mapWidth  * 0.5f;
			float halfMapHeight = mapHeight * 0.5f;
			float halfNodeSize  = nodeSize  * 0.5f;
			controlNodes = new ControlNode[nodeCountXY, nodeCountXY];

			for (int chunkY = 0; chunkY < map.chunkCountXY; ++chunkY)
			{
				for (int chunkX = 0; chunkX < map.chunkCountXY; ++chunkX)
				{
					for (int voxelY = 0; voxelY < map.voxelCountXY; ++voxelY)
					{
						for (int voxelX = 0; voxelX < map.voxelCountXY; ++voxelX)
						{
							int mapX = chunkX * map.voxelCountXY + voxelX;
							int mapY = chunkY * map.voxelCountXY + voxelY;
							Vector3 position
								= new Vector2(
									-halfMapWidth  + mapX * nodeSize + halfNodeSize,
									-halfMapHeight + mapY * nodeSize + halfNodeSize);
							bool active
								= map.chunkGrid[chunkX, chunkY].voxelGrid[voxelX, voxelY] > 0
								? true : false;
							controlNodes[mapX, mapY] 
								= new ControlNode(position, nodeSize, active);
						}
					}
				}
			}
			squares = new Square[nodeCountXY - 1, nodeCountXY - 1];
			for (int x = 0; x < nodeCountXY - 1; ++x)
			{
				for (int y = 0; y < nodeCountXY - 1; ++y)
				{
					squares[x, y]
						= new Square(
							controlNodes[x, y + 1],
							controlNodes[x + 1, y + 1],
							controlNodes[x + 1, y],
							controlNodes[x, y]);
				}
			}
		}
	}

	private class Square
	{
		public Node        centerTop, centerRight, centerBottom, centerLeft;
		public ControlNode topLeft, topRight, bottomRight, bottomLeft;
		public int         configuration;

		public Square(
			ControlNode topLeft,
			ControlNode topRight,
			ControlNode bottomRight,
			ControlNode bottomLeft)
		{
			this.topLeft     = topLeft;
			this.topRight    = topRight;
			this.bottomRight = bottomRight;
			this.bottomLeft  = bottomLeft;
			centerTop        = topLeft.right;
			centerRight      = bottomRight.above;
			centerBottom     = bottomLeft.right;
			centerLeft       = bottomLeft.above;

			UpdateConfiguration();
		}

		public void UpdateConfiguration()
		{
			if (topLeft.active)     configuration |= 8;
			if (topRight.active)    configuration |= 4;
			if (bottomRight.active)	configuration |= 2;
			if (bottomLeft.active)  configuration |= 1;
		}
	}

	private class Node
	{
		public Vector3 position;

		public Node(Vector3 position)
		{
			this.position = position;
		}
	}

	private class ControlNode : Node
	{
		public bool active;
		public Node above, right;

		public ControlNode(Vector3 position, float squareSize, bool active)
			: base(position)
		{
			this.active = active;
			above  = new Node(position + Vector3.up    * squareSize * 0.5f);
			right  = new Node(position + Vector3.right * squareSize * 0.5f);
		}
	}
}
*/
  