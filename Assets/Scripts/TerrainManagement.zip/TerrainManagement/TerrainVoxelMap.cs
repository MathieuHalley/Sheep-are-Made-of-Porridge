﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class TerrainVoxelMap : MonoBehaviour
{
	public  float                size = 2f;
	public  int                  voxelCountXY = 8;
	public  int                  chunkCountXY = 2;
	public  TerrainVoxelGrid     voxelGridPrefab;
	public  TerrainVoxelGrid[,]  chunkGrid;
	private float                chunkSize, voxelSize, halfSize;
	private TerrainMeshGenerator terrainMeshGenerator;

	private void Awake()
	{
		halfSize  = size      * 0.5f;
		chunkSize = size      / chunkCountXY;
		voxelSize = chunkSize / voxelCountXY; 
		chunkGrid = new TerrainVoxelGrid[chunkCountXY, chunkCountXY];
		
		for (int y = 0; y < chunkCountXY; ++y)
		{
			for (int x = 0; x < chunkCountXY; ++x)
			{
				chunkGrid[x,y] = CreateChunk(x, y);
			}
		}

//		BoxCollider2D collider = gameObject.AddComponent<BoxCollider2D>();
//		collider.size          = new Vector2(size, size);
		terrainMeshGenerator   = GetComponent<TerrainMeshGenerator>();
		terrainMeshGenerator.Initialize(this, voxelSize);
	}
	
	private TerrainVoxelGrid CreateChunk(int x, int y)
	{
		TerrainVoxelGrid chunk = Instantiate(voxelGridPrefab) as TerrainVoxelGrid;
		chunk.Initialize(voxelCountXY, chunkSize, false);
		chunk.transform.parent        = transform;
		chunk.transform.localPosition = new Vector3(x * chunkSize - halfSize, 
			                                        y * chunkSize - halfSize);
		chunk.transform.localScale    = Vector3.one;
		chunk.name                    = "Chunk: (" + x + "," + y + ")";
		return chunk;
	}

	private void Update()
	{
		if (Input.GetMouseButton(0))
		{
			Vector3 worldSpaceMousePosition 
				= Camera.main.ScreenToWorldPoint(Input.mousePosition);
			SetVoxelState(transform.InverseTransformPoint(worldSpaceMousePosition), true);
			//Collider2D selectedVoxel        
			//	= Physics2D.OverlapCircle(worldSpaceMousePosition, voxelSize);
			//if (selectedVoxel != null && selectedVoxel.gameObject == gameObject)
			//{
			//}
		}
	}

	private Vector2 GetVoxelIndexByPosition(Vector3 position)
	{
		int voxelX = (int)((position.x + halfSize) / voxelSize);
		int voxelY = (int)((position.y + halfSize) / voxelSize);
		return new Vector2(voxelX, voxelY);
	}

	private Vector2 GetChunkIndexByPosition(Vector3 position)
	{
		int chunkX = (int)((position.x + halfSize) / chunkSize);
		int chunkY = (int)((position.y + halfSize) / chunkSize);
		return new Vector2(chunkX, chunkY);
	}

	private void SetVoxelState(Vector3 position, bool newState = true)
	{
		Vector2 voxelIndex = GetVoxelIndexByPosition(position);
		Vector2 chunkIndex = GetChunkIndexByPosition(position);
		int chunkIndexX    = (int)(chunkIndex.x % chunkCountXY);
		int chunkIndexY    = (int)(chunkIndex.y % chunkCountXY);
		chunkGrid[chunkIndexX, chunkIndexY]
			.SetVoxelState(
			(int)(voxelIndex.x % voxelCountXY), 
			(int)(voxelIndex.y % voxelCountXY), 
			newState);
		terrainMeshGenerator
			.SetControlNodeState(
			(int)(voxelIndex.x), 
			(int)(voxelIndex.y), 
			newState);
		terrainMeshGenerator.GenerateMesh();
	}
}
