﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System;

public class TerrainQuadTreeTest : MonoBehaviour
{
	public TerrainQuadTree quadTree;
	public Vector2         mapSize;

	void Awake()
	{
		mapSize  = new Vector2(8, 8);
		quadTree = new TerrainQuadTree(Vector3.zero, mapSize);
	}

	void Update()
	{
		Vector3 worldMousePosition = Camera.main.ScreenToWorldPoint(Input.mousePosition);
		if (Input.GetMouseButton(0))
		{
			quadTree.Insert(new TerrainPoint(quadTree, worldMousePosition, true));
		}
		if (Input.GetMouseButtonDown(1))
		{
			
		}
		if (Input.GetKeyDown(KeyCode.Space))
		{
			quadTree.Clear();
		}
	}

	void OnDrawGizmos()
	{
		if (quadTree == null)
			return;
		IQuadTree[] nodes = quadTree.DepthFirst().Where(x => x != null).ToArray();
		for (int i = 0; i < nodes.Length-1; ++i)
		{
			Gizmos.color = Color.gray;
			if (nodes[i].Point != null)
			{
				Gizmos.DrawCube(nodes[i].Bounds.center, nodes[i].Bounds.size);
			}
			else
			{
				Gizmos.DrawWireCube(nodes[i].Bounds.center, nodes[i].Bounds.size);
			}
			Gizmos.color = Color.green;
		}
		Gizmos.color = Color.white;
		Gizmos.DrawWireSphere(Camera.main.ScreenToWorldPoint(Input.mousePosition),0.5f);
	}
}

public interface IPoint
{
	Vector2   Position { get; }
	IQuadTree Node     { get; }
	void AssignQuadTree(IQuadTree quadTree);
}

public interface ITerrainPoint : IPoint
{
	new ITerrainQuadTree Node { get; }
}

public interface IQuadTree
{
	Bounds      Bounds  { get; }
	IPoint      Point   { get; }
	IQuadTree[] Corners { get; }
	IQuadTree   Parent  { get; }
	string      MapHash { get; }

	void     Clear();
	bool     Insert(IPoint point);
	IPoint[] QueryPosition(Vector3 position);
	IPoint[] QueryRange(Bounds range);
	void     Subdivide();
	void     SetMapHash(string newHash);
}

public interface ITerrainQuadTree : IQuadTree
{
	new  ITerrainPoint Point { get; }
	new  ITerrainQuadTree[] Corners { get; }
	bool Insert(ITerrainPoint point);
}

public class TerrainPoint : Point
{
	private const int            MinTerrainHeight = 0;
	private const int            MaxTerrainHeight = 1;
	private float                elevation;
	private ITerrainQuadTree     node;
	public  new ITerrainQuadTree Node      { get { return node; } }
	public  float                Elevation { get { return elevation; } }
	public  bool                 State     { get { return elevation != 0 ? true : false; } }

	public TerrainPoint(ITerrainQuadTree node, Vector2 position, float elevation = 0) 
		: base(node, position)
	{
		SetElevation(elevation);
	}

	public TerrainPoint(ITerrainQuadTree node, Vector2 position, bool state)
	: base(node, position)
	{
		elevation = 1;
	}

	private void SetElevation(
		float newElevation, 
		int   min = MinTerrainHeight, 
		int   max = MaxTerrainHeight)
	{
		elevation = Mathf.Clamp(newElevation, Mathf.Max(min, 0), max);
	}
}

public class Point : IPoint
{
	private Vector2   position;
	private IQuadTree node;
	public  Vector2   Position { get { return position; } }
	public  IQuadTree Node     { get { return node; } }
	public  Point(IQuadTree node, Vector2 position)
	{
		this.node     = node;
		this.position = position;
	}

	public void AssignQuadTree(IQuadTree quadTree)
	{
		this.node = quadTree;
	}
}

//-------

public class TerrainQuadTree : QuadTree, ITerrainQuadTree
{
	private    ITerrainPoint      point;
	private    ITerrainQuadTree[] corners;
	public new ITerrainPoint      Point   { get { return point; } }
	public new ITerrainQuadTree[] Corners { get { return corners; } }


	public TerrainQuadTree(Vector3 center, Vector3 size, ITerrainQuadTree parent = null)
		: base(center, size, parent)
	{
		corners = new ITerrainQuadTree[4] { null, null, null, null };
	}

	public bool Insert(ITerrainPoint point)
	{
		return base.Insert(point);
	}
}

public class QuadTree : IQuadTree
{
	private Bounds      bounds;
	private string      mapHash;
	private IQuadTree   parent;
	private IQuadTree[] corners;
	private IPoint      point;

	protected const int MaxPoints = 1;
	protected const int MaxLevels = 5;
	protected const int TopLeftCorner     = 0;
	protected const int TopRightCorner    = 1;
	protected const int BottomRightCorner = 2;
	protected const int BottomLeftCorner  = 3;

	public Bounds       Bounds  { get { return bounds; } }
	public IPoint       Point   { get { return point; } }
	public IQuadTree    Parent  { get { return parent; } }
	public IQuadTree[]  Corners { get { return corners; } }
	public string       MapHash { get { return mapHash; } }

	public QuadTree(Vector3 center, Vector3 size, IQuadTree parent = null)
	{
		this.parent = parent;
		bounds      = new Bounds(center, size);
		corners     = new IQuadTree[4] { null, null, null, null };
		point       = null;

		if (parent != null)
		{
			mapHash = new string(new char[parent.MapHash.Length + 1]);
			mapHash = parent.MapHash + Array.IndexOf(parent.Corners, this).ToString();
		}
		else
		{
			//	This is the root node
			mapHash = new string(new char[0]);
		}
	}

	public void Clear()
	{
		for (int i = 0; i < corners.Length; ++i)
		{
			corners[i].Clear();
			corners[i] = null;
		}
	}

	public bool Insert(IPoint point)
	{
		if (!bounds.Contains(point.Position))
		{
			return false;
		}
		if (this.point == null && corners[TopLeftCorner] == null)
		{
			this.point = point;
			point.AssignQuadTree(this);
			return true;
		}
		else if (mapHash.Length > MaxLevels)
		{
			return false;
		}
		else if (this.point != null && corners[TopLeftCorner] == null)
		{
			Subdivide();
		}
		for (int i = 0; i < corners.Length; ++i)
		{
			if (corners[i].Insert(point))
			{
				this.point = null;
				return true;
			}
		}
		return false;
	}

	public IPoint[] QueryPosition(Vector3 position)
	{
		List<IPoint> foundPoints = new List<IPoint>();

		if (bounds.Contains(position))
		{
			foundPoints.Add(point);
		}
		else
		{
			return foundPoints.ToArray();
		}
		if (corners[TopLeftCorner] == null)
		{
			return foundPoints.ToArray();
		}
		for (int i = 0; i < corners.Length; ++i)
		{
			foundPoints.AddRange(corners[i].QueryPosition(position));
		}
		return foundPoints.ToArray();
	}

	public IPoint[] QueryRange(Bounds range)
	{
		List<IPoint> foundPoints = new List<IPoint>();

		if (!bounds.Intersects(range))
		{
			return foundPoints.ToArray();
		}
		if (range.Contains(point.Position))
		{
			foundPoints.Add(point);
		}
		if (corners[TopLeftCorner] == null)
		{
			return foundPoints.ToArray();
		}
		for (int i = 0; i < corners.Length; ++i)
		{
			foundPoints.AddRange(corners[i].QueryRange(range));
		}
		return foundPoints.ToArray();
	}

	public void Subdivide()
	{
		Vector2 quarterSize = bounds.extents * 0.5f;
		corners[TopLeftCorner]     = new QuadTree(bounds.center + new Vector3(-quarterSize.x,  quarterSize.y), bounds.extents, this);
		corners[TopRightCorner]    = new QuadTree(bounds.center + new Vector3( quarterSize.x,  quarterSize.y), bounds.extents, this);
		corners[BottomRightCorner] = new QuadTree(bounds.center + new Vector3( quarterSize.x, -quarterSize.y), bounds.extents, this);
		corners[BottomLeftCorner]  = new QuadTree(bounds.center + new Vector3(-quarterSize.x, -quarterSize.y), bounds.extents, this);
		corners[TopLeftCorner]    .SetMapHash(MapHash + TopLeftCorner    .ToString());
		corners[TopRightCorner]   .SetMapHash(MapHash + TopRightCorner   .ToString());
		corners[BottomRightCorner].SetMapHash(MapHash + BottomRightCorner.ToString());
		corners[BottomLeftCorner] .SetMapHash(MapHash + BottomLeftCorner .ToString());
	}
	public void SetMapHash(String newHash)
	{
		mapHash = newHash;
	}
}

public static class QuadTreeSearchExtensions
{
	public static IEnumerable<IQuadTree> BreadthFirst(this IQuadTree root)
	{
		Queue<IQuadTree> nodes = new Queue<IQuadTree>(new IQuadTree[] { root });
		while (nodes.Any())
		{
			IQuadTree node = nodes.Dequeue();
			yield return node;
			if (node == null) continue;
			for (int i = 0; i < node.Corners.Length; ++i)
			{
				nodes.Enqueue(node.Corners[i]);
			}
		}
	}

	public static IEnumerable<IQuadTree> DepthFirst(this IQuadTree root)
	{
		Stack<IQuadTree> nodes = new Stack<IQuadTree>(new IQuadTree[] { root });
		while (nodes.Any())
		{
			IQuadTree node = nodes.Pop();
			yield return node;
			if (node == null) continue;
			for (int i = 0; i < node.Corners.Length; ++i)
			{
				nodes.Push(node.Corners[i]);
			}
		}
	}
}