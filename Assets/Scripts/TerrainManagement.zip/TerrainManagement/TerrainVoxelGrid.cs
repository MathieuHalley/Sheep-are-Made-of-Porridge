﻿using UnityEngine;
using System.Collections;

[SelectionBase]
public class TerrainVoxelGrid : MonoBehaviour
{
	public  bool        showVoxelNodes;
	public  int[,]      voxelGrid;
	public  float       voxelSize;
	private Material[,] voxelMaterials;
	private float       gridSize;

	public void Initialize(int voxelCountXY, float gridSize, bool showVoxelNodes = false)
	{
		if (voxelCountXY <= 0)
		{
			voxelCountXY = 1;
		}

		this.showVoxelNodes = showVoxelNodes;
		this.gridSize       = gridSize;
		this.voxelSize      = gridSize / voxelCountXY;
		this.voxelGrid      = new int[voxelCountXY, voxelCountXY];
		this.voxelMaterials = new Material[voxelCountXY, voxelCountXY];

		if (showVoxelNodes)
		{
			for (int y = 0; y < voxelCountXY; ++y)
			{
				for (int x = 0; x < voxelCountXY; ++x)
				{
					CreateVoxel(x, y);
				}
			}
			SetAllVoxelColoursByCurrentState();
		}
	}

	public void SetVoxelState(int x, int y, bool newState)
	{
		if (x >= gridSize || y >= gridSize || x < 0 || y < 0)
		{
			return;
		}
		voxelGrid[x, y] = newState ? 1 : 0;
		SetVoxelColourByCurrentState(x, y);
	}

	private void CreateVoxel(int x, int y)
	{
		GameObject voxel = GameObject.CreatePrimitive(PrimitiveType.Quad);
		Vector3    localPosition 
			= new Vector3((x + 0.5f) * voxelSize, 
			              (y + 0.5f) * voxelSize, -0.1f);

		voxel.transform.parent        = transform;
		voxel.transform.localPosition = localPosition;
		voxel.transform.localScale    = Vector3.one * voxelSize * 0.25f;
		voxelMaterials[x, y]          = voxel.GetComponent<MeshRenderer>().material;
	}

	private void SetAllVoxelColoursByCurrentState()
	{
		for (int y = 0; y < voxelGrid.GetLength(1); ++y)
		{
			for (int x = 0; x < voxelGrid.GetLength(0); ++x)
			{
				SetVoxelColourByCurrentState(x, y);
			}
		}
	}

	private void SetVoxelColourByCurrentState(int x, int y)
	{
		if (showVoxelNodes)
		{
			voxelMaterials[x, y].color 
				= voxelGrid[x, y] != 0 
				? Color.black : Color.white;
		}
	}
}
