﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public interface ITreeObject
{
	bool Active { get; set; }
	bool Updated { get; set; }
	Transform Transform { get; }
	Vector3 Position { get; }
}

public interface ITreeBoxObject : ITreeObject
{
	Bounds Region { get; }
}
public interface ITreeSphereObject : ITreeObject
{
	BoundingSphere Region { get; }
}

public class Octree<T,O> where O : ITreeObject
{
	const int MinRegionSize = 1;	// The minumum size for enclosing region is a 1x1x1 cube.
	/// <summary>
	/// These are items which we're waiting to insert into the data structure. 
	/// We want to accrue as many objects in here as possible before injecting them into the tree. 
	/// This is slightly more cache friendly.
	/// </summary>
	static Queue<O> objectsPendingInsertion = new Queue<O>();
	static bool     treeReady = false;	// The tree has a few objects which need to be inserted before it is complete
	static bool     treeBuilt = false;	// There is no pre-existing tree yet.

	List<O>     objects;
	Octree<T, O>   parent;
	Octree<T, O>[] childNodes = new Octree<T, O>[8];
	Bounds      region;
	/// <summary>
	/// This is a bitmask indicating which child nodes are actively being used.
	/// It adds slightly more complexity, but is faster for performance since there is only one comparison instead of 8.
	/// </summary>
	byte activeNodes = 0;
	/// <summary>
	/// this is how many frames we'll wait before deleting an empty tree branch. Note that this is not a constant. The maximum lifespan doubles
	/// every time a node is reused, until it hits a hard coded constant of 64
	/// </summary>
	int maxTreeLifetime = 8;
	int currentLifetime = -1;

	private Octree(Bounds region, List<O> objects)
	{
		this.region = region;
		this.objects = objects;
		currentLifetime = -1;
	}

	public Octree() : this(new Bounds(Vector3.zero, Vector3.zero), new List<O>()) { }
	public Octree(Bounds region) : this(region, new List<O>()) { }

	public void ObjectNodeAssignmentUpdate(Time deltaTime)
	{
		if (!treeBuilt)
			return;

		if (objects.Count == 0)
		{
			if (childNodes.Length == 0)
			{
				if (currentLifetime == -1)
					currentLifetime = maxTreeLifetime;
				else if (currentLifetime > 0)
					currentLifetime--;
			}
		}
		else
		{
			if (currentLifetime != -1)
			{
				if (maxTreeLifetime <= 64)
					maxTreeLifetime *= 2;
				currentLifetime = -1;
			}
		}
		List<O> movedObjects = new List<O>(objects.Count);
		for (int i = 0; i < objects.Count; ++i)
		{
			if (objects[i].Updated)
				movedObjects.Add(objects[i]);
		}

		for (int i = 0, objectCount = objects.Count; i < objectCount; ++i)
		{
			if (!objects[i].Active)
			{
				if (movedObjects.Contains(objects[i]))
					movedObjects.Remove(objects[i]);
				objects.RemoveAt(i--);
				objectCount--;
			}
		}

		for (int flags = activeNodes, i = 0; flags > 0; flags >>= 1, ++i)
		{
			if ((flags & 1) == 1)
				childNodes[i].ObjectNodeAssignmentUpdate(deltaTime);
		}

		for (int i = 0; i < movedObjects.Count; ++i)
		{
			Octree<T, O> current = this;
			while (!(movedObjects[i] is ITreeBoxObject && RegionContainsAABB(current.region, ((ITreeBoxObject)movedObjects[i]).Region))
				&& !(movedObjects[i] is ITreeSphereObject && RegionContainsSphere(current.region, ((ITreeSphereObject)movedObjects[i]).Region)))
			{
				if (current.parent != null)
					current = current.parent;
				else
					break;
			}
			objects.Remove(movedObjects[i]);
			current.Insert(movedObjects[i]);
		}

		for (int flags = activeNodes, i = 0; flags > 0; flags >>= 1, ++i)
		{
			if ((flags & 1) == 1 && childNodes[i].currentLifetime == 0)
			{
				childNodes[i] = null;
				activeNodes ^= (byte)(1 << i);
			}
		}
		/*	This code tracks collision within the octtree
				if (parent == null)
				{
					List<IntersectionRecord> intersectionRecord = GetIntersection(new List<O>());
					for (int i = 0; i < intersectionRecord.Count; ++i)
					{
						if (intersectionRecord[i].obj == null)
							intersectionRecord[i].obj.HandleIntersection(intersectionRecord);
						if (intersectionRecord[i].otherObj == null)
							intersectionRecord[i].otherObj.HandleIntersection(intersectionRecord);
					}

				}
			*/
	}

	public void Add(List<O> objects)
	{
		for (int i = 0; i < objects.Count; ++i)
			objectsPendingInsertion.Enqueue(objects[i]);
		treeReady = false;
	}

	public void Add(O obj)
	{
		objectsPendingInsertion.Enqueue(obj);
		treeReady = false;
	}

	public void Remove(O obj)
	{
		if (objects.Contains(obj))
			objects.Remove(obj);
	}

	private void TreeInsertionQueueUpdate()
	{
		if (!treeBuilt)
		{
			while (objectsPendingInsertion.Count != 0)
			{
				objects.Add(objectsPendingInsertion.Dequeue());
				BuildTree();
			}
		}
		else
		{
			while (objectsPendingInsertion.Count != 0)
			{
				Insert(objectsPendingInsertion.Dequeue());
			}
		}
		treeReady = true;
	}

	private void BuildTree()
	{
		if (objects.Count <= 1)
			return;
		if (region.size == Vector3.zero)
			region = FindEnclosingCube(objects);

		Bounds[]  childRegions    = CreateChildRegions(region);
		List<O>   delistedObjects = new List<O>();
		List<O>[] objectLists     = new List<O>[8];

		for (int i = 0; i < objectLists.Length; ++i)
			objectLists[i] = new List<O>();

		for (int i = 0; i < objects.Count; ++i)
		{
			for (int j = 0; j < 8; ++j)
			{
				if ((objects[i] is ITreeBoxObject    && RegionContainsAABB(region,   ((ITreeBoxObject)objects[i]).Region))
				||  (objects[i] is ITreeSphereObject && RegionContainsSphere(region, ((ITreeSphereObject)objects[i]).Region)))
				{
					objectLists[j].Add(objects[i]);
					delistedObjects.Add(objects[i]);
					break;
				}
			}
		}
		for (int i = 0; i < delistedObjects.Count; ++i)
			objects.Remove(delistedObjects[i]);

		for (int i = 0; i < 8; ++i)
		{
			if (objectLists[i].Count != 0)
			{
				activeNodes |= (byte)(1 << i);
				childNodes[i] = CreateNode(childRegions[i], objectLists[i]);
				childNodes[i].BuildTree();
			}
		}
		treeBuilt = true;
		treeReady = true;
	}

	private Octree<T,O> CreateNode(Bounds region, List<O> objects)
	{
		if (objects.Count == 0)
			return null;
		Octree<T, O> newOctree = new Octree<T, O>(region, objects);
		newOctree.parent = this;
		return newOctree;
	}

	private Octree<T,O> CreateNode(Bounds region, O obj)
	{
		List<O> objects = new List<O>(1);
		objects.Add(obj);
		return CreateNode(region, objects);
	}

	private void Insert(O obj)
	{
		if (objects.Count <= 1 && activeNodes == 0)
		{
			objects.Add(obj);
			return;
		}

		Bounds[] childRegions = CreateChildRegions(region);
		if ((obj is ITreeBoxObject    && RegionContainsAABB(region,   ((ITreeBoxObject)obj).Region))
		||  (obj is ITreeSphereObject && RegionContainsSphere(region, ((ITreeSphereObject)obj).Region)))
		{
			bool found = false;
			for (int i = 0; i < 8; ++i)
			{
				if ((obj is ITreeBoxObject    && RegionContainsAABB(childRegions[i],   ((ITreeBoxObject)obj).Region))
				||  (obj is ITreeSphereObject && RegionContainsSphere(childRegions[i], ((ITreeSphereObject)obj).Region)))
				{
					if (childNodes[i] != null)
						childNodes[i].Insert(obj);
					else
					{
						childNodes[i].CreateNode(childRegions[i], obj);
						activeNodes |= (byte)(1 << i);
					}
				}
				found = true;
			}
			if (!found)
				objects.Add(obj);
		}
		else
			BuildTree();
	}

	private Bounds[] CreateChildRegions(Bounds region)
	{
		Bounds[] childRegions = new Bounds[8];

		if (region.size.x >= MinRegionSize 
		 && region.size.y >= MinRegionSize 
		 && region.size.z >= MinRegionSize)
			return childRegions;

		Vector3 halfExtents = region.extents * 0.5f;
		Vector3 center      = region.center;
		Vector3 maxCenter   = center + halfExtents;
		Vector3 minCenter   = center - halfExtents;

		childRegions[0] = new Bounds(minCenter, region.extents);
		childRegions[1] = new Bounds(new Vector3(maxCenter.x, minCenter.y, minCenter.z), region.extents);
		childRegions[2] = new Bounds(new Vector3(maxCenter.x, minCenter.y, maxCenter.z), region.extents);
		childRegions[3] = new Bounds(new Vector3(minCenter.x, minCenter.y, maxCenter.z), region.extents);
		childRegions[4] = new Bounds(new Vector3(minCenter.x, maxCenter.y, minCenter.z), region.extents);
		childRegions[5] = new Bounds(new Vector3(maxCenter.x, maxCenter.y, minCenter.z), region.extents);
		childRegions[6] = new Bounds(maxCenter, region.extents);
		childRegions[7] = new Bounds(new Vector3(minCenter.x, maxCenter.y, maxCenter.z), region.extents);

		return childRegions;
	}

	private bool RegionContainsAABB(Bounds region, Bounds AABB)
	{
		return region.Contains(AABB.min) && region.Contains(AABB.max) ? true : false;
	}
	private bool RegionContainsSphere(Bounds region, BoundingSphere sphere)
	{
		Bounds expandedRegion = new Bounds(region.center, region.extents + Vector3.one * (sphere.radius * 2));
		return expandedRegion.Contains(sphere.position) ? true : false;
	}
	private bool RegionContainsPoint(Bounds region, ITreeObject obj)
	{
		return region.Contains(obj.Position) ? true : false;
	}
	private bool RegionIntersectsAABB(Bounds region, Bounds AABB)
	{
		return region.Intersects(AABB) ? true : false;
	}
	private bool RegionIntersectsSphere(Bounds region, BoundingSphere sphere)
	{
		float squaredDistance = 0f;
		float difference = 0f;
		if (sphere.position.x < region.min.x)
		{
			difference = sphere.position.x - region.min.x;
			squaredDistance += difference * difference;
		}
		else if (sphere.position.x > region.max.x)
		{
			difference = sphere.position.x - region.max.x;
			squaredDistance += difference * difference;
		}
		if (sphere.position.y < region.min.y)
		{
			difference = sphere.position.y - region.min.y;
			squaredDistance += difference * difference;
		}
		else if (sphere.position.y > region.max.y)
		{
			difference = sphere.position.y - region.max.y;
			squaredDistance += difference * difference;
		}
		if (sphere.position.z < region.min.z)
		{
			difference = sphere.position.z - region.min.z;
			squaredDistance += difference * difference;
		}
		else if (sphere.position.z > region.max.z)
		{
			difference = sphere.position.z - region.max.z;
			squaredDistance += difference * difference;
		}

		return squaredDistance <= sphere.radius * sphere.radius ? true : false;
	}
	private Bounds FindEnclosingCube(List<O> objects)
	{
		Vector3 min = Vector3.zero;
		Vector3 max = Vector3.zero;
		for (int i = 0; i < objects.Count; ++i)
		{
			if (min.x > objects[i].Position.x)
				min.x = objects[i].Position.x;
			else if (max.x < objects[i].Position.x)
				max.x = objects[i].Position.x;

			if (min.y > objects[i].Position.y)
				min.y = objects[i].Position.y;
			else if (max.y < objects[i].Position.y)
				max.y = objects[i].Position.y;

			if (min.z > objects[i].Position.z)
				min.z = objects[i].Position.z;
			else if (max.z < objects[i].Position.z)
				max.z = objects[i].Position.z;
		}

		int size = (int)Mathf.Max(max.x - min.x, max.y - min.y, max.z - min.z);
		int powerOfTwo = 1;
		while (powerOfTwo < size) { powerOfTwo <<= 1; }
		
		return new Bounds((min + max) * 0.5f, Vector3.one * powerOfTwo);
	}
}
