﻿/*
 * Copyright (c) 2010 Daniel Rasmussen <cyclotis04.dev@gmail.com>.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *   
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

public class MatrixSpacePartition<T>
{
	public delegate T Initializer(int x, int y);

	private const    int   DefaultBlockMagnitude = 4;
	private const    float DefaultSaturationThreshold = 0.75f;
	private readonly int   _blockMagnitude;
	private readonly int   _blockSize;
	private readonly float _saturationThreshold;
	private MatrixSpacePartitionNode _root;

	public MatrixSpacePartition() 
		: this(DefaultBlockMagnitude, DefaultSaturationThreshold) { }
	public MatrixSpacePartition(int blockMagnitude)
		: this(blockMagnitude, DefaultSaturationThreshold) { }
	public MatrixSpacePartition(int blockMagnitude, float saturationThreshold)
	{
		if (blockMagnitude < 0 || blockMagnitude > 30)
			throw new System.ArgumentOutOfRangeException("blockMagnitude", "Block magnitude must be between 0 and 30, inclusive.");
		if (saturationThreshold < 0 || saturationThreshold > 1)
			throw new System.ArgumentOutOfRangeException("saturationThreshold", "Saturation threshold must be between 0 and 1, inclusive.");

		_blockMagnitude = blockMagnitude;
		_blockSize = (1 << blockMagnitude);
		_saturationThreshold = saturationThreshold;
		_root = new MatrixSpacePartitionNode(this);
	}

	public int BlockMagnitude { get { return _blockMagnitude; } }
	public int BlockSize { get { return _blockSize; } }
	public Bounds Bounds { get { return _root.GetBounds(); } }
	public float SaturationThreshold { get { return _saturationThreshold; } }
	public T this[Vector3 p]
	{
		get { return Get(p); }
		set { Set(p, value); }
	}
	public T this[int x, int y]
	{
		get { return Get(x, y); }
		set { Set(x, y, value); }
	}
	public T Get(Vector3 p)
	{
		return _root.Get(p);
	}
	public T Get(int x, int y)
	{
		return _root.Get(new Vector3(x, y));
	}
	public T Get(Vector3 p, Initializer initializer)
	{
		T value;
		_root.Get(p, initializer, out value);
		return value;
	}
	public T Get(int x, int y, Initializer initializer)
	{
		return Get(new Vector3(x, y), initializer);
	}

	public T[,] GetRegion(Bounds bounds)
	{
		var data = new T[(int)bounds.size.x, (int)bounds.size.y];
		_root.CopyInto(ref data, bounds);
		return data;
	}

	public void Set(Vector3 p, T value)
	{
		_root.Set(p, value);
	}

//	public void Set(int x, int y, T value)
//	{
//
//		_root(new Vector3(x, y), value);
//	}

	public void SetRegion(Bounds region, Initializer initializer, bool overwrite)
	{
		_root.SetRegion(region, initializer, overwrite);
	}

	private sealed class MatrixSpacePartitionNode
	{
		private readonly Bounds  _bounds;
		private readonly Vector3 _center;
		private readonly bool    _isRootNode;
		private readonly MatrixSpacePartition<T> _root;
		private T[,] data;
		private MatrixSpacePartitionNode[] nodes;
		private float saturation;
		public MatrixSpacePartitionNode(MatrixSpacePartition<T> root)
		{
			_root = root;
			_isRootNode = true;
			nodes = new MatrixSpacePartitionNode[4];
			_center = new Vector3(0, 0);
		}
		public MatrixSpacePartitionNode(
			MatrixSpacePartition<T> root, 
			Bounds bounds, bool aggregate)
		{
			_root = root;
			_bounds = bounds;
			_center = new Vector3(bounds.min.x + bounds.extents.x, bounds.max.y + bounds.extents.y);
			if (aggregate || bounds.size.x <= _root.BlockSize)
			{
				nodes = new MatrixSpacePartitionNode[4];
			}
			else
			{
				data = new T[(int)bounds.size.x, (int)bounds.size.y];
				saturation = 1f;
			}
		}
		private MatrixSpacePartitionNode(
			MatrixSpacePartition<T> root, 
			Bounds bounds, 
			MatrixSpacePartitionNode subNode) 
			: this(root, bounds, false)
		{
			Bounds b = subNode.GetBounds();
			nodes[GetQuadrant(subNode.GetBounds().min)] = subNode;
		}

		private Vector3 Center { get { return _center; } }

		private IEnumerable<MatrixSpacePartitionNode> NullCheckedNodes { get { return nodes.Where(node => node != null); } }

		public Bounds GetBounds()
		{
			if (!_isRootNode)
				return _bounds;
			Bounds b = new Bounds(new Vector3(-0.5f, -0.5f), new Vector3(1, 1));
			if (nodes[0] == null && nodes[1] == null && nodes[2] == null && nodes[3] == null)
				return b;
			b = nodes.First(node => node != null).GetBounds();
			return NullCheckedNodes
				.Aggregate(b, (current, node) => BoundingRectangle(current, node.GetBounds());
		}

		private T GetPointData(Vector3 p)
		{
			Bounds b = GetBounds();
			return this.data[(int)p.x - (int)b.min.x, (int)p.y - (int)b.min.y];
		}
		private T GetPointData(int x, int y)
		{
			Bounds b = GetBounds();
			return this.data[x - (int)b.min.x, y - (int)b.min.y];
		}
		private T GetPointData(Vector3 p, Bounds b)
		{
			return this.data[(int)p.x - (int)b.min.x, (int)p.y - (int)b.min.y];
		}
		private T GetPointData(int x, int y, Bounds b)
		{
			return this.data[x - (int)b.min.x, y - (int)b.min.y];
		}

		public void CopyInto(ref T[,] data, Bounds bounds)
		{
			if (this.data == null)
			{
				foreach (MatrixSpacePartitionNode node in NullCheckedNodes)
					node.CopyInto(ref data, bounds);
			}
			else
			{
				Bounds b = GetBounds();
				int minX = Mathf.Max((int)b.min.x, (int)bounds.min.x);
				int minY = Mathf.Max((int)b.min.y, (int)bounds.min.y);
				int maxX = Mathf.Min((int)b.max.x, (int)bounds.max.x);
				int maxY = Mathf.Min((int)b.max.y, (int)bounds.max.y);
				for (int x = minX; x < maxX; ++x)
				{
					for (int y = minY; y < maxY; ++y)
					{
						data[x - (int)bounds.min.x, y - (int)bounds.min.y]
							= GetPointData(x,y,b);
					}
				}
			}
		}

		public T Get(Vector3 p)
		{
			if (this.data != null)
				return GetPointData(p);
			int q = GetQuadrant(p);
			if (nodes[q] != null && nodes[q].GetBounds().Contains(p))
				return nodes[q].Get(p);
			else
				return default(T);
		}

		public bool Get(Vector3 p, Initializer initializer, out T value)
		{
			if (data != null)
			{
				value = GetPointData(p);
				return false;
			}
			int q = GetQuadrant(p);
			if (nodes[q] != null && nodes[q].GetBounds().Contains(p))
			{
				if(nodes[q].Get(p, initializer, out value))
				{
					RecalculateNodeSaturation();
					return true;
				}
			}
			value = initializer((int)p.x, (int)p.y);
			if (AddToSubnode(p, value))
			{
				RecalculateNodeSaturation();
				return true;
			}
			else
				return false;
		}

		public bool Set(Vector3 p, T value)
		{
			if (data != null)
			{
				T pointData = GetPointData(p);
				pointData = value;
			}
			else if (AddToSubnode(p, value))
			{
				RecalculateNodeSaturation();
				return true;
			}
			return false;
		}

		public bool SetRegion(Bounds region, Initializer initializer, bool overwrite)
		{
			if (data != null)
			{
				if (initializer == null)
					return false;

				Bounds b = GetBounds();
				int minX = Mathf.Max((int)b.min.x, (int)region.min.x);
				int minY = Mathf.Max((int)b.min.y, (int)region.min.y);
				int maxX = Mathf.Min((int)b.max.x, (int)region.max.x);
				int maxY = Mathf.Min((int)b.max.y, (int)region.max.y);

				if (overwrite)
				{
					for (int x = minX; x < maxX; ++x)
					{
						for (int y = minY; y < maxY; ++y)
						{
							data[x - (int)b.min.x, y - (int)b.min.y] = initializer.Invoke(x, y);
						}
					}
				}
				else
				{
					for (int x = minX; x < maxX; ++x)
					{
						for (int y = minY; y < maxY; ++y)
						{
							if (data[x - (int)b.min.x, y - (int)b.min.y].Equals(default(T)))
							{
								data[x - (int)b.min.x, y - (int)b.min.y] = initializer.Invoke(x, y);
							}
						}
					}
				}
			}

			bool dirtied = false;
			IEnumerable<MatrixSpacePartitionNode> containedNodes
				= NullCheckedNodes
				.Select(n => new { n, nodeBounds = n.GetBounds() })
				.Where(n => NodeBoundsIsOrContainsRegion(n.nodeBounds, region))
				.Select(n => n.n);

			foreach (MatrixSpacePartitionNode node in containedNodes)
			{
				dirtied = node.SetRegion(region, initializer, overwrite);
				if (dirtied)
					RecalculateNodeSaturation();
				return dirtied;
			}

			for (int i = 0; i < 4; ++i)
			{
				Bounds qb = GetQuadrantBounds(i);
				if (!qb.Intersects(region))
					continue;
				if (nodes[i] == null)
				{
					nodes[i] = new MatrixSpacePartitionNode(_root, qb, false);
					nodes[i].SetRegion(region, initializer, overwrite);
					dirtied = true;
				}
				else if (NodeBoundsIsOrContainsRegion(qb, region))
				{
					dirtied 
						= nodes[i].SetRegion(region, initializer, overwrite) 
						|| dirtied;
				}
				else
				{
					qb = 
				}
			}
		}

		private bool NodeBoundsIsOrContainsRegion(Bounds bounds, Bounds region)
		{
			if (bounds.min == Vector3.Min(bounds.min, region.min)
			 && bounds.max == Vector3.Max(bounds.max, region.max))
				return true;
			else
				return false;
		}

		private int GetQuadrant(Vector3 p)
		{
			return (int)p.x >= (int)Center.x
				? ((int)p.y >= (int)Center.y ? 0 : 3) 
				: ((int)p.y >= (int)Center.y ? 1 : 2);
		}

		private Bounds GetQuadrantBounds(int index)
		{
			Vector3 boundsMin;
			if (!_isRootNode)
			{
				Bounds b = GetBounds();
				switch (index)
				{
					case 1:
					boundsMin = new Vector3(b.min.x, b.center.y);
				break;
				}
			}
			else
			{

			}

		private void RecalculateNodeSaturation()
		{
			if (_isRootNode)
				saturation = 0;
			else
			{
				Bounds b = GetBounds();
				double s = NullCheckedNodes
					.Select(n => new { n, nodeBoundsArea = (n._bounds.size.x * n._bounds.size.x) / (double)(b.size.x * b.size.y) })
					.Select(n => n.nodeBoundsArea * n.n.saturation)
					.Sum();
				if (s >= _root.SaturationThreshold)
					AggregateNodes();
				else
					saturation = s;
			}
		}
	}
}
